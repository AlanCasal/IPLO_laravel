<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">

    
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    
    <link href="<?php echo e(asset('img/icono.png')); ?>" rel="icon" type="image/png" />

    
    <link href="<?php echo e(asset('vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">

    
    <link href="<?php echo e(asset('vendor/fontawesome-free/css/all.min.css')); ?>" rel="stylesheet" type="text/css">
    

    
    <link href="<?php echo e(asset('css/clean-blog.min.css')); ?>" rel="stylesheet" />

    
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet" type="text/css" media="screen" />

    <title>Lágrimas Bajo Tierra I - Iluminados por la Oscuridad</title>
</head>
<body>
<?php /**PATH C:\xampp\htdocs\_web\IPLO_laravel\resources\views/components/head.blade.php ENDPATH**/ ?>