<!-- Page Header -->
<header class="masthead" style='background-image: url(<?php echo e(asset("img/{$headerImg}")); ?>)'>
    <div class="overlay"></div>
    <div class="container">
        <div class="row">
            <div class="col-lg-8 col-md-10 mx-auto">
                <div class="site-heading" style="text-shadow: 2px 2px 5px black">
                    
                    <?php
                        echo $headerText;
                    ?>
                </div>
            </div>
        </div>
    </div>
</header>
<?php /**PATH C:\xampp\htdocs\_web\IPLO_laravel\resources\views/components/header.blade.php ENDPATH**/ ?>