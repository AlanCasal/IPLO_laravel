<br/>
<br/>

<span id="top" class="btn float-right mb-4 mr-4 iralinicio">
    IR AL INICIO <i class="fas fa-arrow-circle-up fa-lg"></i>
</span>
<?php /**PATH C:\xampp\htdocs\_web\IPLO_laravel\resources\views/components/iralinicio.blade.php ENDPATH**/ ?>