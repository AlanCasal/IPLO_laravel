<!-- Bootstrap core JavaScript -->
<script src="<?php echo e(asset('vendor/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

<!-- Custom scripts for this template -->
<script src="<?php echo e(asset('js/clean-blog.min.js')); ?>"></script>

<!-- My scripts -->
<script src="<?php echo e(asset('js/misc.js')); ?>"></script>


<script src="<?php echo e(asset('js/jqBootstrapValidation.js')); ?>"></script>
<script src="<?php echo e(asset('js/contact_me.js')); ?>"></script>
<?php /**PATH C:\xampp\htdocs\_web\IPLO_laravel\resources\views/components/scripts.blade.php ENDPATH**/ ?>